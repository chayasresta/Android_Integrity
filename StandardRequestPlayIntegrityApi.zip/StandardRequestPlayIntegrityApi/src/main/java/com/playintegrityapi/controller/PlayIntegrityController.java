package com.playintegrityapi.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonObject;
import com.playintegrity.dto.RequestParams;
import com.playintegrityapi.ValidationResult;
import com.playintegrityapi.service.PlayIntegrityService;
import com.playintegrityapi.service.RequestDto;

@RestController
@RequestMapping("/api/v1")
public class PlayIntegrityController {

	@Autowired
	private PlayIntegrityService playIntegrityService;
	
	    @PostMapping("/decode")
	    public ResponseEntity<String> decodeIntegrityToken(
	            //@RequestBody RequestDto requestDto,
	            @RequestHeader("deviceType") String deviceType,
	            @RequestHeader("packageName") String packageName,
	            @RequestBody RequestParams requestParams)throws Exception{
	    String integrityToken = requestParams.getIntegrityToken();
	    String expectedRequestHash=requestParams.getExpectedRequestHash();
	    String expectedPackageName= requestParams.getExpectedPackageName();
	        
	        try {
	        	String accessToken = playIntegrityService.getAccessToken();
	        	System.out.println("accessToken: " + accessToken);
	        	ValidationResult validationResult= playIntegrityService.decodeIntegrityToken(accessToken, integrityToken, expectedRequestHash, expectedPackageName);
	            //ValidationResult validationResult = playIntegrityService.validateTokenPayload(decodedResponse, expectedRequestHash, expectedPackageName);

	            JsonObject response = new JsonObject();
	            response.addProperty("isValid", validationResult.isValid());
	            JsonObject validationDetails = new JsonObject();
	            validationResult.getDetails().forEach(validationDetails::addProperty);
	            response.add("validationDetails", validationDetails);
	            //response.addProperty("originalResponse", validationResult.getOriginalResponse()); // Include the original response


	            return ResponseEntity.ok(response.toString());
	        } catch (Exception e) {
	            JsonObject errorResponse = new JsonObject();
	            errorResponse.addProperty("error", "Error decoding integrity token: " + e.getMessage());
	            return new ResponseEntity<>(errorResponse.toString(), HttpStatus.BAD_REQUEST);
	        }
	    }
}
	   /* @PostMapping("/driverAcceptTrip")
	    public ResponseEntity<String> driverAcceptTrip(
	            @RequestHeader("Authorization") String authorization,
	            @RequestHeader("deviceType") String deviceType,
	            @RequestHeader("packageName") String packageName,
	            @RequestBody RequestParams requestParams) {

	        String accessToken = authorization.replace("Bearer ", "");
	        JsonObject response = playIntegrityService.handleRequest(requestParams, accessToken, deviceType, packageName);
	        
	        return ResponseEntity.ok(response.toString());
	    }
}*/

	/*@PostMapping("/decode")
	public String decodeIntegrityToken(@RequestBody RequestDto requestDto) throws Exception {
		String integrityToken = requestDto.getIntegrityToken();
		System.out.println("integrityToken: " + integrityToken);

		try {
			String accessToken = playIntegrityService.getAccessToken();
			System.out.println("accessToken: " + accessToken);
			return playIntegrityService.decodeIntegrityToken(accessToken, integrityToken);
		} catch (IOException e) {
			e.printStackTrace();
			return "Error: " + e.getMessage();
		}
	}
}
	*/

	/*@GetMapping("/get-decode-integrity-token")
	public String getdecodeIntegrityToken(@RequestParam String integrityToken) throws Exception {
		try {
			String accessToken = playIntegrityService.getAccessToken();
			System.out.println(accessToken);
			return playIntegrityService.decodeIntegrityToken(accessToken, integrityToken);
		} catch (IOException e) {
			e.printStackTrace();
			return "Error: " + e.getMessage();
		}
	}*/
	

	/*@GetMapping("/get-integrity-token")
	public String getIntegrityToken(@RequestParam String nonce) throws Exception {
		try {
			String accessToken = playIntegrityService.getAccessToken();
			System.out.println(accessToken);
			return playIntegrityService.requestPlayIntegrityToken(accessToken, nonce);
		} catch (IOException e) {
			e.printStackTrace();
			return "Error: " + e.getMessage();
		}
	}*/

