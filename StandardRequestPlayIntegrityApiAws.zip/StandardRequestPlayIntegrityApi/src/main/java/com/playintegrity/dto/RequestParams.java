package com.playintegrity.dto;

public class RequestParams {
    private String offerId;
    private String driverOfferId;
    private String driverId;
    private Double latitude;
    private Double longitude;
    private Boolean isChainingFlow;
    private String integrityToken;
    private String expectedRequestHash;
    private String expectedPackageName;


    // Getters and Setters

    public String getExpectedRequestHash() {
		return expectedRequestHash;
	}

	public void setExpectedRequestHash(String expectedRequestHash) {
		this.expectedRequestHash = expectedRequestHash;
	}

	public String getExpectedPackageName() {
		return expectedPackageName;
	}

	public void setExpectedPackageName(String expectedPackageName) {
		this.expectedPackageName = expectedPackageName;
	}

	public String getOfferId() {
        return offerId;
    }

    public void setOfferId(String offerId) {
        this.offerId = offerId;
    }

    public String getDriverOfferId() {
        return driverOfferId;
    }

    public void setDriverOfferId(String driverOfferId) {
        this.driverOfferId = driverOfferId;
    }

    public String getDriverId() {
        return driverId;
    }

    public void setDriverId(String driverId) {
        this.driverId = driverId;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Boolean getIsChainingFlow() {
        return isChainingFlow;
    }

    public void setIsChainingFlow(Boolean isChainingFlow) {
        this.isChainingFlow = isChainingFlow;
    }

    public String getIntegrityToken() {
        return integrityToken;
    }

    public void setIntegrityToken(String integrityToken) {
        this.integrityToken = integrityToken;
    }
}
