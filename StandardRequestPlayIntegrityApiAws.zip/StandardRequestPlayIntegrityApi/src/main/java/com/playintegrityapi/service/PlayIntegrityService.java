package com.playintegrityapi.service;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Collection;
import java.util.Collections;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.auth.oauth2.ServiceAccountCredentials;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.playintegrity.dto.RequestParams;
import com.playintegrityapi.ValidationResult;

@Service
public class PlayIntegrityService {
	//private static final Logger LOGGER = LoggerFactory.getLogger(PlayIntegrityService.class);

	@Value("${google.client.secret.file}")
	private String clientSecretFile;

	@Value("${google.package.name}")
	private String packageName;
	//private static final String clientSecretFile = "/Users/vn577dk/Downloads/StandardRequestPlayIntegrityApi/src/main/resources/srestaproject-7e23f9a81d72.json";
	private static final String PLAY_INTEGRITY_API_SCOPE = "https://www.googleapis.com/auth/playintegrity";
	private static final long ALLOWED_WINDOW_MILLIS = 10 * 60 * 1000;
	//private static final String TOKENS_DIRECTORY_PATH = "tokens";
	//private static final JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();
	// private static final String DECODE_URL =
	// "https://playintegrity.googleapis.com/v1/{packageName}:decodeIntegrityToken";
	private static final Collection<String> SCOPES = Collections
			.singletonList("https://www.googleapis.com/auth/playintegrity");

	public String getAccessToken() throws IOException {
		try (InputStream credentialsStream = new FileInputStream(clientSecretFile)) {
			GoogleCredentials credentials = ServiceAccountCredentials.fromStream(credentialsStream)
					.createScoped(Collections.singletonList(PLAY_INTEGRITY_API_SCOPE));
			credentials.refreshIfExpired();
			return credentials.getAccessToken().getTokenValue();
		}
	}

	public ValidationResult decodeIntegrityToken(String accessToken, String integrityToken, String expectedRequestHash, String expectedPackageName) throws Exception {
		// Define the URL for the Play Integrity API decode request
		String url = "https://playintegrity.googleapis.com/v1/com.walpoc.driver:decodeIntegrityToken";

		// Prepare the HTTP request
		HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
		connection.setRequestMethod("POST");
		connection.setRequestProperty("Authorization", "Bearer " + accessToken);
		connection.setRequestProperty("Content-Type", "application/json");
		connection.setDoOutput(true);
		System.out.println("properties....."+connection.getRequestProperties());
		// Create the JSON payload for the request
		String requestBody = "{\n" + "  \"integrityToken\": \"" + integrityToken + "\"\n" + "}";
		System.out.println("Request URL: " + url);
		System.out.println("Request Method: " + connection.getRequestMethod());
		System.out.println("Request Body: " + requestBody);
		// Write the request body
		try (OutputStream os = connection.getOutputStream()) {
			byte[] input = requestBody.getBytes("utf-8");
			os.write(input, 0, input.length);
		}

		// Read the response
		int responseCode = connection.getResponseCode();
		if (responseCode == HttpURLConnection.HTTP_OK) {
			try (BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"))) {
				StringBuilder response = new StringBuilder();
				String responseLine;
				while ((responseLine = br.readLine()) != null) {
					response.append(responseLine.trim());
				}

				// Parse the JSON response
				JsonObject jsonResponse = JsonParser.parseString(response.toString()).getAsJsonObject();
				jsonResponse.addProperty("Original Response", response.toString());
				System.out.println("json response...." + jsonResponse);
				return validateTokenPayload(jsonResponse, expectedRequestHash, expectedPackageName);
			}
		} else {
			throw new RuntimeException("Failed to decode integrity token: " + responseCode);
		}
	}
	/*private String validateTokenPayload(JsonObject jsonResponse, String expectedRequestHash, String expectedPackageName) {
        JsonObject tokenPayloadExternal = jsonResponse.getAsJsonObject("tokenPayloadExternal");

        // Extract and validate request details
        JsonObject requestDetails = tokenPayloadExternal.getAsJsonObject("requestDetails");
        String requestPackageName = requestDetails.get("requestPackageName").getAsString();
        String requestHash = requestDetails.get("requestHash").getAsString();
        long timestampMillis = requestDetails.get("timestampMillis").getAsLong();
        long currentTimestampMillis = System.currentTimeMillis();

        if (!requestPackageName.equals(expectedPackageName)
                || !requestHash.equals(expectedRequestHash)
                || currentTimestampMillis - timestampMillis > ALLOWED_WINDOW_MILLIS) {
            return "Invalid token!";
        }

        // Extract and validate app integrity
        JsonObject appIntegrity = tokenPayloadExternal.getAsJsonObject("appIntegrity");
        String appRecognitionVerdict = appIntegrity.get("appRecognitionVerdict").getAsString();
        if (!"PLAY_RECOGNIZED".equals(appRecognitionVerdict)) {
            return "App integrity check failed!";
        }

        // Extract and validate device integrity
        JsonObject deviceIntegrity = tokenPayloadExternal.getAsJsonObject("deviceIntegrity");
        String deviceRecognitionVerdict = deviceIntegrity.has("deviceRecognitionVerdict")
                ? deviceIntegrity.getAsJsonArray("deviceRecognitionVerdict").toString()
                : "";
        if (!deviceRecognitionVerdict.contains("MEETS_DEVICE_INTEGRITY")) {
            return "Device integrity check failed!";
        }

        // Extract and validate account details
        JsonObject accountDetails = tokenPayloadExternal.getAsJsonObject("accountDetails");
        String appLicensingVerdict = accountDetails.get("appLicensingVerdict").getAsString();
        if (!"LICENSED".equals(appLicensingVerdict)) {
            return "App licensing check failed!";
        }

        return "Integrity check passed!";
    }*/
	/*public JsonObject handleRequest(RequestParams requestParams, String accessToken, String deviceType, String packageName) {
        // Create the JSON object with the required parameters
        JsonObject jsonInput = new JsonObject();
        jsonInput.addProperty("offerId", requestParams.getOfferId());
        jsonInput.addProperty("driverOfferId", requestParams.getDriverOfferId());
        jsonInput.addProperty("driverId", requestParams.getDriverId());
        jsonInput.addProperty("latitude", requestParams.getLatitude());
        jsonInput.addProperty("longitude", requestParams.getLongitude());
        jsonInput.addProperty("isChainingFlow", requestParams.getIsChainingFlow());
        jsonInput.addProperty("integrityToken", requestParams.getIntegrityToken());

        
        if (requestParams.getIntegrityToken() != null && !requestParams.getIntegrityToken().isEmpty()) {
            boolean isTokenValid = decodeIntegrityToken(requestParams.getIntegrityToken(), jsonInput);
            if (isTokenValid) {
                jsonInput.addProperty("integrityTokenValid", true);
            } else {
                jsonInput.addProperty("integrityTokenValid", false);
            }
        }

        return jsonInput;
    }*/
	public ValidationResult validateTokenPayload(JsonObject jsonResponse, String expectedRequestHash, String expectedPackageName) {
        ValidationResult result = new ValidationResult();
        JsonObject tokenPayloadExternal = jsonResponse.getAsJsonObject("tokenPayloadExternal");

        JsonObject requestDetails = tokenPayloadExternal.getAsJsonObject("requestDetails");
        String requestPackageName = requestDetails.get("requestPackageName").getAsString();
        String requestHash = requestDetails.get("requestHash").getAsString();
        long timestampMillis = requestDetails.get("timestampMillis").getAsLong();
        long currentTimestampMillis = System.currentTimeMillis();

        if (!requestPackageName.equals(expectedPackageName)) {
            result.addDetail("requestPackageName", "FAILED");
        } else {
            result.addDetail("requestPackageName", "PASSED");
        }

        if (!requestHash.equals(expectedRequestHash)) {
            result.addDetail("requestHash", "FAILED");
        } else {
            result.addDetail("requestHash", "PASSED");
        }

        if (Math.abs(currentTimestampMillis - timestampMillis) > ALLOWED_WINDOW_MILLIS) {
            result.addDetail("timestamp", "FAILED");
        } else {
            result.addDetail("timestamp", "PASSED");
        }

        JsonObject appIntegrity = tokenPayloadExternal.getAsJsonObject("appIntegrity");
        String appRecognitionVerdict = appIntegrity.get("appRecognitionVerdict").getAsString();
        if (!"PLAY_RECOGNIZED".equals(appRecognitionVerdict)) {
            result.addDetail("appRecognitionVerdict", "FAILED");
        } else {
            result.addDetail("appRecognitionVerdict", "PASSED");
        }

        JsonObject deviceIntegrity = tokenPayloadExternal.getAsJsonObject("deviceIntegrity");
        String deviceRecognitionVerdict = deviceIntegrity.has("deviceRecognitionVerdict")
                ? deviceIntegrity.getAsJsonArray("deviceRecognitionVerdict").toString()
                : "";
        if (!deviceRecognitionVerdict.contains("MEETS_DEVICE_INTEGRITY")) {
            result.addDetail("deviceRecognitionVerdict", "FAILED");
        } else {
            result.addDetail("deviceRecognitionVerdict", "PASSED");
        }

        JsonObject accountDetails = tokenPayloadExternal.getAsJsonObject("accountDetails");
        String appLicensingVerdict = accountDetails.get("appLicensingVerdict").getAsString();
        if (!"LICENSED".equals(appLicensingVerdict)) {
            result.addDetail("appLicensingVerdict", "FAILED");
        } else {
            result.addDetail("appLicensingVerdict", "PASSED");
        }
        
        return result;
    }
}