package com.playintegrityapi;

import java.util.HashMap;
import java.util.Map;

import com.google.gson.JsonObject;

public class ValidationResult {
    private boolean isValid;
    private Map<String, String> details;
    private JsonObject originalResponse;
    

	
    public ValidationResult() {
        this.isValid = true;
        this.details = new HashMap<>();
    }
	

	public ValidationResult(JsonObject originalResponse) {
		super();
		this.originalResponse = originalResponse;
	}


	public boolean isValid() {
        return isValid;
    }

    public void setValid(boolean isValid) {
        this.isValid = isValid;
    }

    public Map<String, String> getDetails() {
        return details;
    }

    public void addDetail(String key, String value) {
        if ("FAILED".equals(value)) {
            this.isValid = false;
        }
        this.details.put(key, value);
    }
	public void setDetails(Map<String, String> details) {
		this.details = details;
	}

	public JsonObject getOriginalResponse() {
		return originalResponse;
	}

	public void setOriginalResponse(JsonObject originalResponse) {
		this.originalResponse = originalResponse;
	}
	

    
}
