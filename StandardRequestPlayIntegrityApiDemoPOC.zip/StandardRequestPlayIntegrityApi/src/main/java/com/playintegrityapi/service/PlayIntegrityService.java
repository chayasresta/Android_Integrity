package com.playintegrityapi.service;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.Base64;
import java.util.Collection;
import java.util.Collections;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.auth.oauth2.ServiceAccountCredentials;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.playintegrityapi.ValidationResult;


@Service
public class PlayIntegrityService {
	//private static final Logger LOGGER = LoggerFactory.getLogger(PlayIntegrityService.class);
String expectedRequestHash="sss";
	@Value("${google.client.secret.file}")
	private String clientSecretFile;

	@Value("${google.package.name}")
	private String packageName;
	//private static final String clientSecretFile = "/Users/vn577dk/Downloads/StandardRequestPlayIntegrityApi/src/main/resources/srestaproject-7e23f9a81d72.json";
	private static final String PLAY_INTEGRITY_API_SCOPE = "https://www.googleapis.com/auth/playintegrity";
	private static final long ALLOWED_WINDOW_MILLIS = 24 * 60 * 60 * 1000;
	private static final Logger log = Logger.getLogger("PlayIntegrityService");
	//private static final String TOKENS_DIRECTORY_PATH = "tokens";
	//private static final JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();
	// private static final String DECODE_URL =
	// "https://playintegrity.googleapis.com/v1/{packageName}:decodeIntegrityToken";
	private static final Collection<String> SCOPES = Collections
			.singletonList("https://www.googleapis.com/auth/playintegrity");

	public String getAccessToken() throws IOException {
		try (InputStream credentialsStream = new FileInputStream(clientSecretFile)) {
			GoogleCredentials credentials = ServiceAccountCredentials.fromStream(credentialsStream)
					.createScoped(Collections.singletonList(PLAY_INTEGRITY_API_SCOPE));
			credentials.refreshIfExpired();
			return credentials.getAccessToken().getTokenValue();
		}
	} 
	public ValidationResult decodeIntegrityToken(String accessToken, String integrityToken, String generatedRequestHash) throws Exception {
		// Define the URL for the Play Integrity API decode request
		String url = "https://playintegrity.googleapis.com/v1/com.walpoc.driver:decodeIntegrityToken";

		// Prepare the HTTP request
		HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
		connection.setRequestMethod("POST");
		connection.setRequestProperty("Authorization", "Bearer " + accessToken);
		connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
		connection.setDoOutput(true);
		System.out.println("properties....."+connection.getRequestProperties());
		// Create the JSON payload for the request
		String requestBody = "{\n" + "  \"integrityToken\": \"" + integrityToken + "\"\n" + "}";
		System.out.println("Request URL: " + url);
		System.out.println("Request Method: " + connection.getRequestMethod());
		System.out.println("Request Body: " + requestBody);
		// Write the request body
		try (OutputStream os = connection.getOutputStream()) {
			byte[] input = requestBody.getBytes("utf-8");
			os.write(input, 0, input.length);
		}

		// Read the response
		int responseCode = connection.getResponseCode();
		if (responseCode == HttpURLConnection.HTTP_OK) {
			try (BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"))) {
				StringBuilder response = new StringBuilder();
				String responseLine;
				while ((responseLine = br.readLine()) != null) {
					response.append(responseLine.trim());
				}

				// Parse the JSON response
				JsonObject jsonResponse = JsonParser.parseString(response.toString()).getAsJsonObject();
//				jsonResponse.addProperty("Original Response", response.toString());
				System.out.println("json response...." + jsonResponse);
				return validateTokenPayload(jsonResponse, generatedRequestHash);
			}
		} else {
			throw new RuntimeException("Failed to decode integrity token: " + responseCode);
		}
	}
	
	public ValidationResult validateTokenPayload(JsonObject jsonResponse, String generatedRequestHash) {
        ValidationResult result = new ValidationResult();
        JsonObject tokenPayloadExternal = jsonResponse.getAsJsonObject("tokenPayloadExternal");

        JsonObject requestDetails = tokenPayloadExternal.getAsJsonObject("requestDetails");
        String requestPackageName = requestDetails.get("requestPackageName").getAsString();
        String requestHash = requestDetails.get("requestHash").getAsString();
        long timestampMillis = requestDetails.get("timestampMillis").getAsLong();
        //long currentTimestampMillis = ZonedDateTime.now(ZoneOffset.UTC).toInstant().toEpochMilli();
        long currentTimestampMillis = System.currentTimeMillis();
        
        log.info("Current timestamp (millis): " + currentTimestampMillis);
        log.info("Token timestamp (millis): " + timestampMillis);
        log.info("Time difference (millis): " + Math.abs(currentTimestampMillis - timestampMillis));


        if (!requestPackageName.equals(packageName)) {
            result.addDetail("requestPackageName", "FAILED");
        } else {
            result.addDetail("requestPackageName", "PASSED");
        }

        if (!requestHash.equals(generatedRequestHash)) {
            result.addDetail("requestHash", "FAILED");
        } else {
            result.addDetail("requestHash", "PASSED");
        }

        if (Math.abs(currentTimestampMillis - timestampMillis) > ALLOWED_WINDOW_MILLIS) {
            result.addDetail("timestamp", "FAILED");
        } else {
            result.addDetail("timestamp", "PASSED");
        }

        JsonObject appIntegrity = tokenPayloadExternal.getAsJsonObject("appIntegrity");
        String appRecognitionVerdict = appIntegrity.get("appRecognitionVerdict").getAsString();
        if (!"PLAY_RECOGNIZED".equals(appRecognitionVerdict)) {
            result.addDetail("appRecognitionVerdict", "FAILED");
        } else {
            result.addDetail("appRecognitionVerdict", "PASSED");
        }

        JsonObject deviceIntegrity = tokenPayloadExternal.getAsJsonObject("deviceIntegrity");
        String deviceRecognitionVerdict = deviceIntegrity.has("deviceRecognitionVerdict")
                ? deviceIntegrity.getAsJsonArray("deviceRecognitionVerdict").toString()
                : "";
        if (!deviceRecognitionVerdict.contains("MEETS_DEVICE_INTEGRITY")) {
            result.addDetail("deviceRecognitionVerdict", "FAILED");
        } else {
            result.addDetail("deviceRecognitionVerdict", "PASSED");
        }

        JsonObject accountDetails = tokenPayloadExternal.getAsJsonObject("accountDetails");
        String appLicensingVerdict = accountDetails.get("appLicensingVerdict").getAsString();
        if (!"LICENSED".equals(appLicensingVerdict)) {
            result.addDetail("appLicensingVerdict", "FAILED");
        } else {
            result.addDetail("appLicensingVerdict", "PASSED");
        }
        result.setOriginalResponse(jsonResponse); 
        return result;
    }
	public  String generateRequestHash(RequestDto requestDto) throws NoSuchAlgorithmException {
		JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("driverId", requestDto.getDriverId());
        jsonObject.addProperty("driverOfferId", requestDto.getDriverOfferId());
        jsonObject.addProperty("isChainingFlow", requestDto.isChainingFlow());
        jsonObject.addProperty("latitude", requestDto.getLatitude());
        jsonObject.addProperty("longitude", requestDto.getLongitude());
        jsonObject.addProperty("offerId", requestDto.getOfferId());

        // Convert the JsonObject to a JSON string
        String jsonString = jsonObject.toString();

        // Generate the hash
        
        System.out.println("Concatenated String for Hashing: " + jsonString);

        
        /*System.out.println("driverId: " + requestDto.getDriverId());
        System.out.println("driverOfferId: " + requestDto.getDriverOfferId());
        System.out.println("isChainingFlow: " + requestDto.isChainingFlow());
        System.out.println("latitude: " + requestDto.getLatitude());
        System.out.println("longitude: " + requestDto.getLongitude());
        System.out.println("offerId: " + requestDto.getOfferId());

*/
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] encodedHash = digest.digest(jsonString.getBytes(StandardCharsets.UTF_8));

        StringBuilder hexString = new StringBuilder();

        for (byte b : encodedHash) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }
}
	
	