package com.playintegrityapi.service;


public class RequestDto {
	
	
	

	    private String driverId;
	    private String driverOfferId;
	    private boolean isChainingFlow;
	    private double latitude;
	    private double longitude;
	    private String offerId;
	    private String integrityToken;

	    public RequestDto(String driverId, String driverOfferId, boolean isChainingFlow, double latitude,
				double longitude, String offerId, String integrityToken) {
			super();
			this.driverId = driverId;
			this.driverOfferId = driverOfferId;
			this.isChainingFlow = isChainingFlow;
			this.latitude = latitude;
			this.longitude = longitude;
			this.offerId = offerId;
			this.integrityToken = integrityToken;
		}
		// Getters and Setters
	    public String getDriverId() { return driverId; }
	    public void setDriverId(String driverId) { this.driverId = driverId; }
	    public String getDriverOfferId() { return driverOfferId; }
	    public void setDriverOfferId(String driverOfferId) { this.driverOfferId = driverOfferId; }
	    public boolean isChainingFlow() { return isChainingFlow; }
	    public void setChainingFlow(boolean chainingFlow) { this.isChainingFlow = true; }
	    public double getLatitude() { return latitude; }
	    public void setLatitude(double latitude) { this.latitude = latitude; }
	    public double getLongitude() { return longitude; }
	    public void setLongitude(double longitude) { this.longitude = longitude; }
	    public String getOfferId() { return offerId; }
	    public void setOfferId(String offerId) { this.offerId = offerId; }
		public String getIntegrityToken() {
			return integrityToken;
		}
		public void setIntegrityToken(String integrityToken) {
			this.integrityToken = integrityToken;
		}
		
	}

  
 
   

    // Getters and Setters

  

