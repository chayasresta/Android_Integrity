package com.playintegrityapi.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.playintegrity.dto.RequestParams;
import com.playintegrityapi.ValidationResult;
import com.playintegrityapi.service.PlayIntegrityService;
import com.playintegrityapi.service.RequestDto;

@RestController
@RequestMapping("/api/v1")
public class PlayIntegrityController {

	@Autowired
	private PlayIntegrityService playIntegrityService;
	
	    @PostMapping("/decode")
	    public ResponseEntity<String> decodeIntegrityToken(
	    		@RequestHeader("deviceType") String deviceType,
	            @RequestHeader("packageName") String packageName,
	      
	            @RequestBody RequestDto requestDto)throws Exception{
	    String integrityToken = requestDto.getIntegrityToken();
	   
	        
	        try {
	        	
	        	
	        	String accessToken = playIntegrityService.getAccessToken();
	        	String generatedRequestHash = playIntegrityService.generateRequestHash(requestDto);
	            System.out.println("Generated Request Hash: " + generatedRequestHash);
	        	System.out.println("accessToken: " + accessToken);
	        	ValidationResult validationResult= playIntegrityService.decodeIntegrityToken(accessToken, integrityToken, generatedRequestHash);
	            //ValidationResult validationResult = playIntegrityService.validateTokenPayload(decodedResponse, expectedRequestHash, expectedPackageName);

	            JsonObject response = new JsonObject();
	            response.add("originalResponse", validationResult.getOriginalResponse());
	            response.addProperty("isValid", validationResult.isValid());
	            JsonObject validationDetails = new JsonObject();
	            validationResult.getDetails().forEach(validationDetails::addProperty);
	            //response.addProperty("originalResponse", validationResult.getOriginalResponse()); // Include the original response
	             
	            response.add("validationDetails", validationDetails);

	            return ResponseEntity.ok(response.toString());
	        } catch (Exception e) {
	            JsonObject errorResponse = new JsonObject();
	            errorResponse.addProperty("error", "Error decoding integrity token: " + e.getMessage());
	            return new ResponseEntity<>(errorResponse.toString(), HttpStatus.BAD_REQUEST);
	        }
	    }
}
	
	

	